from . import cuda

# ASTRAFORGE AMD PATCH: optional Triton kernels: explicit GEMM and native HIP kernels do not require Triton.
try:
    from . import triton
except ModuleNotFoundError as exc:
    if exc.name != 'triton':
        raise
    triton = None
